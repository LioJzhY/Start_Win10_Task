@echo off
if /i "%~1" neq "hide" (
    start "" /min "%~f0" hide
    exit
)

set "self_pid=%_pid%"

taskkill /im Taskmgr.exe >nul 2>&1
timeout /nobreak /t 0 >nul 2>&1
%SystemRoot%\SysWOW64\Taskmgr.exe >nul 2>&1

taskkill /f /pid %self_pid% >nul 2>&1
exit